// This code is for creating static columns or perfom crud operation in coulmns which are avilable in tabel

import { DataTypes } from 'sequelize';
import sequelize from './db.js';

const Model = sequelize.define('test_table', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  firstname: {
    type: DataTypes.STRING,
    allowNull: false
  }
}, 
{
  tableName: 'test_table'
});

export default Model;



// //////////////////////          this code is for dynamic column creation           ////////////////////////////

// // model.js

// const { DataTypes } = require('sequelize');
// const sequelize = require('./db.js');

// let DynamicModel;

// async function initializeDatabase() {
//   try {
//     await sequelize.authenticate();
//     console.log('Connection to database has been established successfully.');
//     await createOrUpdateDynamicModel([]);
//     console.log('Dynamic model created or updated successfully.');
//   } catch (error) {
//     console.error('Unable to connect to the database:', error);
//   }
// }

// async function createOrUpdateDynamicModel(columns) {
//   try {
//     const dynamicColumns = {};
//     columns.forEach((column) => {
//       dynamicColumns[column] = {
//         type: DataTypes.TEXT,
//         allowNull: true,
//       };
//     });

//     DynamicModel = sequelize.define('test_table', dynamicColumns, {
//       tableName: 'test_table' 
//     });

//     await DynamicModel.sync({ alter: true });
//     console.log("DynamicModel created or updated successfully");
//   } catch (error) {
//     console.error('Error creating or updating DynamicModel:', error);
//     throw new Error(error.message);
//   }
// }

// async function insertRecord(record) {
//   try {
//     await createOrUpdateDynamicModel(Object.keys(record));
//     await DynamicModel.create(record);
//     console.log("Record inserted successfully");
//   } catch (error) {
//     console.error('Error saving Data:', error);
//     throw new Error(error.message);
//   }
// }

// async function fetchDynamicRecords() {
//   try {
//     const records = await DynamicModel.findAll();
//     return records;
//   } catch (error) {
//     console.error('Error fetching Data:', error);
//     throw new Error('Server Error');
//   }
// }

// async function deleteDynamicRecord(id) {
//   try {
//     const deletedCount = await DynamicModel.destroy({ where: { id } });
//     return deletedCount;
//   } catch (error) {
//     console.error('Error deleting record:', error);
//     throw new Error('Server Error');
//   }
// }

// async function updateDynamicRecord(id, data) {
//   try {
//     const [updatedCount] = await DynamicModel.update(data, { where: { id } });
//     return updatedCount;
//   } catch (error) {
//     console.error('Error updating record:', error);
//     throw new Error('Server Error');
//   }
// }

// module.exports = {
//   initializeDatabase,
//   insertRecord,
//   fetchDynamicRecords,
//   deleteDynamicRecord,
//   updateDynamicRecord
// };
