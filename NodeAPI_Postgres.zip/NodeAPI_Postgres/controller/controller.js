
////// ///////////////////         this code is for working with both index.js and index_dev.js file  //////////////////////////////////

import Model from '../models/model.js';

// Lambda event handler
export async function handleRoute(event) {
  let response;
  switch (true) {
    case event.route === "insert": {
      response = await insert(event);
      break;
    }
    case event.route === "fetch": {
      response = await fetch(event);
      break;
    }
    case event.route.startsWith("deleteUser"): {
      response = await deleteUser(event);
      break;
    }
    case event.route.startsWith("updateUser"): {
      response = await updateUser(event);
      break;
    }
    default: {
      response = {
        statusCode: 500,
        body: "Internal Server Error",
      };
    }
  }
  return response;
}

// Express request handlers
export async function insertHandler(req, res) {
  const event = {
    route: 'insert',
    body: req.body
  };
  const response = await insert(event);
  res.status(response.statusCode).json(JSON.parse(response.body));
}

export async function fetchHandler(req, res) {
  const event = {
    route: 'fetch',
    query: req.query
  };
  const response = await fetch(event);
  res.status(response.statusCode).json(JSON.parse(response.body));
}

export async function deleteUserHandler(req, res) {
  const event = {
    route: `deleteUser/${req.params.id}`,
    id: req.params.id
  };
  const response = await deleteUser(event);
  res.status(response.statusCode).json(JSON.parse(response.body));
}

export async function updateUserHandler(req, res) {
  const event = {
    route: `updateUser/${req.params.id}`,
    id: req.params.id,
    body: req.body
  };
  const response = await updateUser(event);
  res.status(response.statusCode).json(JSON.parse(response.body));
}

// Database operations
async function insert(event) {
  try {
    const data = event.body;

    // Check if data is an array
    if (!Array.isArray(data)) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Input should be an array of records" })
      };
    }

    // Log the data to verify its structure
    console.log("Data inside insert:", data);

    // Perform bulk insertion
    await Model.bulkCreate(data); // Using bulkCreate to insert multiple records
    return {
      statusCode: 201,
      body: JSON.stringify({ result: "Data Inserted Successfully" })
    };
  } catch (error) {
    console.error('Error saving Data:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message })
    };
  }
}

async function fetch(event) {
  try {
    const { limit, offset, id, sortBy, sortOrder } = event.query || {};

    // Pagination: Apply limit and offset if provided
    let options = {};
    if (limit) {
      options.limit = parseInt(limit);
    }
    if (offset) {
      options.offset = parseInt(offset);
    }

    // Sorting: Apply sorting options if provided
    if (sortBy && sortOrder) {
      const order = sortOrder.toLowerCase() === 'desc' ? 'DESC' : 'ASC';
      options.order = [[sortBy, order]];
    }

    // Fetch total count of items (for pagination metadata)
    const totalCount = await Model.count();

    // Fetch users based on pagination and sorting options
    const userList = await Model.findAll(options);

    if (userList.length === 0) {
      return {
        statusCode: 200,
        body: JSON.stringify({ data: [], meta: {} })
      };
    }

    // Calculate metadata
    const currentPage = options.offset + 1;
    const pageSize = userList.length;
    const totalPages = Math.ceil(totalCount / (parseInt(limit) || 1));

    // Construct metadata object
    const metadata = {
      currentPage,
      totalPages,
      pageSize,
      totalItems: totalCount
    };

    // Construct response object
    const response = {
      data: userList,
      meta: metadata
    };

    return {
      statusCode: 200,
      body: JSON.stringify(response)
    };
  } catch (error) {
    console.error('Error fetching Data:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Server Error" })
    };
  }
}

async function deleteUser(event) {
  try {
    const id = event.id;
    const deletedCount = await Model.destroy({ where: { id } });
    if (deletedCount === 0) {
      return {
        statusCode: 404,
        body: JSON.stringify({ message: "User not found" })
      };
    } else {
      return {
        statusCode: 200,
        body: JSON.stringify({ msg: "User Record deleted successfully." })
      };
    }
  } catch (error) {
    console.error('Error deleting user:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Server Error" })
    };
  }
}

async function updateUser(event) {
  try {
    const id = event.id;
    const data = event.body;
    const [updatedCount] = await Model.update(data, { where: { id } });
    if (updatedCount === 0) {
      return {
        statusCode: 404,
        body: JSON.stringify({ message: "User not found" })
      };
    } else {
      return {
        statusCode: 200,
        body: JSON.stringify({ msg: "User Record updated successfully." })
      };
    }
  } catch (error) {
    console.error('Error updating user:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Server Error" })
    };
  }
}


///////////////////////        this code is working for aws properly    //////////////////////////////////


// import Model from '../models/model.js';

// export async function handleRoute(event) {
//   let response;
//   switch (true) {
//     case event.route === "insert": {
//       response = await insert(event);
//       break;
//     }
//     case event.route === "fetch": {
//       response = await fetch();
//       break;
//     }
//     case event.route.startsWith("deleteUser"): {
//       response = await deleteUser(event);
//       break;
//     }
//     case event.route.startsWith("updateUser"): {
//       response = await updateUser(event);
//       break;
//     }
//     default: {
//       response = {
//         statusCode: 500,
//         body: "Internal Server Error",
//       };
//     }
//   }
//   return response;
// }


// async function insert(event) {
//   try {
//     const data = event.body;

//     console.log("Data inside insert:", data);
//     await Model.create(data);
//     return {
//       statusCode: 201,
//       body: JSON.stringify({ result: "Data Inserted Successfully" })
//     };
//   } catch (error) {
//     console.error('Error saving Data:', error);
//     return {
//       statusCode: 500,
//       body: JSON.stringify({ error: error.message })
//     };
//   }
// }

// async function fetch() {
//   try {
//     const userList = await Model.findAll();
//     if (userList.length === 0) {
//       return {
//         statusCode: 200,
//         body: JSON.stringify({ message: "No data found" })
//       };
//     } else {
//       return {
//         statusCode: 200,
//         body: JSON.stringify(userList)
//       };
//     }
//   } catch (error) {
//     console.error('Error fetching Data:', error);
//     return {
//       statusCode: 500,
//       body: JSON.stringify({ result: "Server Error" })
//     };
//   }
// }

// // async function deleteUser(event) {
// //   try {
// //     console.log(event);
// //     // const id = event.route.split("/")[1];
// //     const id = event.pathParameters.id;
// //     console.log("id inside delete :", id);
// //     const deletedCount = await Model.destroy({ where: { id } });
// //     if (deletedCount === 0) {
// //       return {
// //         statusCode: 404,
// //         body: JSON.stringify({ message: "User not found" })
// //       };
// //     } else {
// //       return {
// //         statusCode: 200,
// //         body: JSON.stringify({ msg: "User Record deleted successfully." })
// //       };
// //     }
// //   } catch (error) {
// //     console.error('Error deleting user:', error);
// //     return {
// //       statusCode: 500,
// //       body: JSON.stringify({ error: "Server Error" })
// //     };
// //   }
// // }

// // async function updateUser(event) {
// //   try {
// //     // const id = event.route.split("/")[1];
// //     const id = event.pathParameters.id;

// //     console.log("id inside update :", id);

// //     const data = event.body;
// //     const [updatedCount] = await Model.update(data, { where: { id } });
// //     if (updatedCount === 0) {
// //       return {
// //         statusCode: 404,
// //         body: JSON.stringify({ message: "User not found" })
// //       };
// //     } else {
// //       return {
// //         statusCode: 200,
// //         body: JSON.stringify({ msg: "User Record updated successfully." })
// //       };
// //     }
// //   } catch (error) {
// //     console.error('Error updating user:', error);
// //     return {
// //       statusCode: 500,
// //       body: JSON.stringify({ error: "Server Error" })
// //     };
// //   }
// // }

// async function deleteUser(event) {
//   try {
//     // const id = event.queryStringParameters.id; // Get id from query parameters

//      const id = event.id; // Get id from query parameters
     
//     console.log("id inside delete :", id);
//     const deletedCount = await Model.destroy({ where: { id } });
//     if (deletedCount === 0) {
//       return {
//         statusCode: 404,
//         body: JSON.stringify({ message: "User not found" })
//       };
//     } else {
//       return {
//         statusCode: 200,
//         body: JSON.stringify({ msg: "User Record deleted successfully." })
//       };
//     }
//   } catch (error) {
//     console.error('Error deleting user:', error);
//     return {
//       statusCode: 500,
//       body: JSON.stringify({ error: "Server Error" })
//     };
//   }
// }

// async function updateUser(event) {
//   try {
//     const id = event.id; // Get id from query parameters

//     console.log("id inside update :", id);

//     const data = event.body;
//     const [updatedCount] = await Model.update(data, { where: { id } });
//     if (updatedCount === 0) {
//       return {
//         statusCode: 404,
//         body: JSON.stringify({ message: "User not found" })
//       };
//     } else {
//       return {
//         statusCode: 200,
//         body: JSON.stringify({ msg: "User Record updated successfully." })
//       };
//     }
//   } catch (error) {
//     console.error('Error updating user:', error);
//     return {
//       statusCode: 500,
//       body: JSON.stringify({ error: "Server Error" })
//     };
//   }
// }



////////////////////         this code is for dynamic column creation          /////////////////////////

// const {
//   insertRecord,
//   fetchDynamicRecords,
//   deleteDynamicRecord,
//   updateDynamicRecord,
// } = require('../models/model.js');


// async function insert(data) {
//   try {
//     const { id, firstname } = data;
//     // Assuming id and firstname are required fields for insertion
//     if (!id || !firstname) {
//       throw new Error('Both id and firstname are required for insertion.');
//     }
//     // Assuming data is an object containing id and firstname
//     await insertRecord(data);
//     return { result: "Data Inserted Successfully" };
//   } catch (error) {
//     console.error('Error saving Data:', error);
//     throw error;
//   }
// }

// async function fetch() {
//   try {
//     const records = await fetchDynamicRecords();
//     if (records.length === 0) {
//       throw new Error('No data found');
//     }
//     return records;
//   } catch (error) {
//     console.error('Error fetching Data:', error);
//     throw error;
//   }
// }

// async function deleteUser(id) {
//   try {
//     if (!id) {
//       throw new Error('ID is required for deletion.');
//     }
//     const deletedCount = await deleteDynamicRecord(id);
//     if (deletedCount === 0) {
//       throw new Error('Record not found');
//     }
//     return { message: "Record deleted successfully" };
//   } catch (error) {
//     console.error('Error deleting record:', error);
//     throw error;
//   }
// }

// async function updateUser(id, data) {
//   try {
//     const { firstname } = data;
//     if (!id || !firstname) {
//       throw new Error('Both id and firstname are required for updating.');
//     }
//     const updatedCount = await updateDynamicRecord(id, data);
//     if (updatedCount === 0) {
//       throw new Error('Record not found');
//     }
//     return { message: "Record updated successfully" };
//   } catch (error) {
//     console.error('Error updating record:', error);
//     throw error;
//   }
// }

// module.exports = {
//   insert,
//   fetch,
//   deleteUser,
//   updateUser
// };
