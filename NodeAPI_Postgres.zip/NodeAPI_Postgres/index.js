// This code is for creating static columns or perfom crud operation in coulmns which are avilable in tabel  second


import express from 'express';
import Model from './models/model.js';
import sequelize from './models/db.js';
import * as Controller from './controller/controller.js';

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// No need to define routes here

async function initializeDatabase() {
  try {
    await sequelize.authenticate();
    console.log('Connection to database has been established successfully.');

    await Model.sync({ alter: true });
    console.log('User table synced successfully.');
  } catch (error) {
    console.error('Unable to connect to the database:', error);
  }
}

// Define a Lambda handler function
export async function handler(event, context) {
  console.log("Incoming event:", JSON.stringify(event, null, 2));
  // Set static data if needed
  // await SECRET_MANAGER.setSecret();
  console.log("event=====", event);
  try {
    // Route the event to appropriate handler function
    const response = await Controller.handleRoute(event);
    console.log("Response:", response);
    return response;
  } catch (error) {
    console.log("Error:", error);
    return {
      statusCode: 500,
      body: `${error}`,
    };
  }
}

// Call initializeDatabase when Lambda starts
initializeDatabase();


// This code is for creating static columns or perfom crud operation in coulmns which are avilable in tabel  first

// import express from 'express';
// import Model from './models/model.js';
// import sequelize from './models/db.js';
// import * as Controller from './controller/controller.js';

// const app = express();

// app.use(express.json());
// app.use(express.urlencoded({ extended: true }));

// app.post("/insert", Controller.insert);
// app.get("/fetch", Controller.fetch);
// app.delete("/delete/:id", Controller.deleteUser);
// app.patch("/update/:id", Controller.updateUser);

// // No need to listen on a port when using AWS Lambda

// async function initializeDatabase() {
//   try {
//     await sequelize.authenticate();
//     console.log('Connection to database has been established successfully.');

//     await Model.sync({ alter: true });
//     console.log('User table synced successfully.');
//   } catch (error) {
//     console.error('Unable to connect to the database:', error);
//   }
// }

// // Define a Lambda handler function
// export async function handler(event, context) {
//   // Ensure database initialization
//   await initializeDatabase();

//   // Route incoming requests to Express app
//   return new Promise((resolve, reject) => {
//     const callback = (error, result) => (error ? reject(error) : resolve(result));
//     app(event, context, callback);
//   });
// }


//////////////////////             this code is for dynamic column creation        ///////////////////////////////////////


// const controller = require("./controller/controller");

// exports.handler = async (event, context) => {
//   let statusCode = 200;
//   let responseBody = {};

//   try {
//     console.log("Incoming request:");
//     console.log(event);

//     if (event.route == "insert") {
//       // Assuming event.body contains the data to be inserted
//       const response = await controller.insert(event.body);
//       console.log(response);
//       responseBody = response;
//     } else if (event.route == "fetch") {
//       const response = await controller.fetch();
//       console.log(response);
//       responseBody = response;
//     } else if (event.route == "/delete/:id") {
//       const response = await controller.deleteUser(event.params.id);
//       console.log(response);
//       responseBody = response;
//     } else if (event.route == "/update/:id") {
//       // Assuming event.params.id contains the ID of the record to be updated
//       // and event.body contains the updated data
//       const response = await controller.updateUser(event.params.id, event.body);
//       console.log(response);
//       responseBody = response;
//     } else {
//       statusCode = 404;
//       responseBody = { error: "Route not found" };
//     }

//     console.log("Final response:");
//     console.log(responseBody);
//   } catch (err) {
//     console.error("Error:", err);
//     statusCode = 500;
//     responseBody = { error: err.message };
//   }

//   return {
//     statusCode: statusCode,
//     body: JSON.stringify(responseBody)
//   };
// };
