// // routes/routes.js

// // Import necessary modules
// import express from 'express';
// import { insertRecord, fetchDynamicRecords, deleteDynamicRecord, updateDynamicRecord } from '../models/model.js';

// // Create an Express router
// const router = express.Router();

// // Function to handle route
// async function handleRoute(event) {
//   let response;
//   switch (event.route) {
//     case "get-prediction": {
//       try {
//         const records = await fetchDynamicRecords();
//         if (records.length === 0) {
//           response = {
//             statusCode: 404,
//             body: { message: "No data found" }
//           };
//         } else {
//           response = {
//             statusCode: 200,
//             body: records
//           };
//         }
//       } catch (error) {
//         console.error('Error fetching Data:', error);
//         response = {
//           statusCode: 500,
//           body: { error: error.message }
//         };
//       }
//       break;
//     }
//     default:
//       response = {
//         statusCode: 500,
//         body: { message: "Internal Server Error" }
//       };
//       break;
//   }
//   return response;
// }

// // Define routes
// router.post("/insert", async (req, res) => {
//   try {
//     const data = req.body;
//     await insertRecord(data);
//     res.status(201).json({ result: "Data Inserted Successfully" });
//   } catch (error) {
//     console.error('Error saving Data:', error);
//     return res.status(500).json({ error: error.message }); // Return the error response
//   }
// });

// router.get("/fetch", async (req, res) => {
//   try {
//     const records = await fetchDynamicRecords();
//     if (records.length === 0) {
//       res.status(404).json({ message: "No data found" });
//     } else {
//       res.status(200).json(records);
//     }
//   } catch (error) {
//     console.error('Error fetching Data:', error);
//     res.status(500).json({ error: error.message });
//   }
// });

// router.delete("/delete/:id", async (req, res) => {
//   try {
//     const id = req.params.id;
//     const deletedCount = await deleteDynamicRecord(id);
//     if (deletedCount === 0) {
//       res.status(404).json({ message: "Record not found" });
//     } else {
//       res.status(200).json({ message: "Record deleted successfully" });
//     }
//   } catch (error) {
//     console.error('Error deleting record:', error);
//     res.status(500).json({ error: error.message });
//   }
// });

// router.patch("/update/:id", async (req, res) => {
//   try {
//     const id = req.params.id;
//     const data = req.body;
//     const updatedCount = await updateDynamicRecord(id, data);
//     if (updatedCount === 0) {
//       res.status(404).json({ message: "Record not found" });
//     } else {
//       res.status(200).json({ message: "Record updated successfully" });
//     }
//   } catch (error) {
//     console.error('Error updating record:', error);
//     res.status(500).json({ error: error.message });
//   }
// });

// // Export the router
// export default router;


// import express from 'express';
// import {
//   insert,
//   fetch,
//   deleteUser,
//   updateUser,
// } from '../controller/controller.js';

// const router = express.Router();

// router.post("/insert", insert);
// router.get("/fetch", fetch);
// router.delete("/delete/:id", deleteUser);
// router.patch("/update/:id", updateUser);

// export default router;


// routes.js








////////// //////////////////        create  dynamic columns          ///////////////////////////////////

const express = require('express');
const {
  insert,
  fetch,
  deleteUser,
  updateUser,
} = require('../controller/controller.js');

const router = express.Router();

router.post("/insert", insert);
router.get("/fetch", fetch);
router.delete("/delete/:id", deleteUser);
router.patch("/update/:id", updateUser);

module.exports = router;






// routes.js

// const express = require('express');
// const router = express.Router();
// const {
//   insert,
//   fetch,
//   deleteUser,
//   updateUser,
// } = require('../controller/controller.js');

// router.post("/insert", insert);
// router.get("/fetch", fetch);
// router.delete("/delete/:id", deleteUser);
// router.patch("/update/:id", updateUser);

// module.exports = {
//   handleRoute: router
// };
