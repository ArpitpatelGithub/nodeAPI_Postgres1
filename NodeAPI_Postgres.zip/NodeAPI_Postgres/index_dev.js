// This code is for creating static columns or perfom crud operation in coulmns which are avilable in tabel
// for development


import express from 'express';
import Model from './models/model.js';
import sequelize from './models/db.js';
import { insertHandler, fetchHandler, deleteUserHandler, updateUserHandler } from './controller/controller.js';

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.post("/insert", (req, res) => insertHandler(req, res));
app.get("/fetch", (req, res) => fetchHandler(req, res));
app.delete("/delete/:id", (req, res) => deleteUserHandler(req, res));
app.patch("/update/:id", (req, res) => updateUserHandler(req, res));

async function initializeDatabase() {
  try {
    await sequelize.authenticate();
    console.log('Connection to database has been established successfully.');

    await Model.sync({ alter: true });
    console.log('User table synced successfully.');
  } catch (error) {
    console.error('Unable to connect to the database:', error);
  }
}

const PORT = 3000;
app.listen(PORT, async () => {
  console.log(`Server is running on http://localhost:${PORT}`);
  await initializeDatabase();
});


//////////////////////             this code is for dynamic column creation        ///////////////////////////////////////

// const express = require('express');
// const { initializeDatabase } = require('./models/model.js');
// const routes = require('./routes/routes.js');

// const app = express();

// app.use(express.json());
// app.use(express.urlencoded({ extended: true }));
// app.use(routes);

// const PORT = 3000;
// app.listen(PORT, async () => {
//   console.log(`Server is running on http://localhost:${PORT}`);
//   await initializeDatabase();
// });

